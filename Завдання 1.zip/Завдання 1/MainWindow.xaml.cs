﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;

namespace Завдання_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public class User
        {
            public string Login { get; set; }
            public string Password { get; set; }
        }
        // Простий список користувачів для прикладу
        private List<User> users = new List<User>
        {
            new User { Login = "admin", Password = "admin123" },
            new User { Login = "user1", Password = "password1" },
            new User { Login = "user2", Password = "password2" }
        };
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Password;

            // Пошук користувача за логіном
            User user = users.FirstOrDefault(u => u.Login == login);

            if (user == null)
            {
                lblMessage.Text = "Користувача не знайдено.";
            }
            else
            {
                // Перевірка пароля
                if (user.Password == password)
                {
                    lblMessage.Text = $"Вітаємо, {login}!";
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show("Неправильний пароль. Замінити старий пароль?",
                                                              "Помилка авторизації", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes)
                    {
                        // Заміна пароля
                        user.Password = password;
                        lblMessage.Text = "Пароль оновлено.";
                    }
                }
            }

        }
    }
}