﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Завдання_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get { return _users; }
            set
            {
                _users = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Users)));
            }
        }
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this; // Дозволяє прив'язку даних до властивості Users

            // Ініціалізація списку користувачів
            Users = new ObservableCollection<User>
            {
                new User { Name = "John Doe", Position = "Developer" },
                new User { Name = "Jane Smith", Position = "Manager" }
            };
        }
        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text;
            string position = txtPosition.Text;

            // Додати нового користувача до списку
            Users.Add(new User { Name = name, Position = position });

            // Очистити текстові поля
            txtName.Clear();
            txtPosition.Clear();

            // Відобразити повідомлення про додавання користувача
            txtMessage.Text = $"Додано нового користувача: {name}";
        }
    }
    public class User
    {
        public string Name { get; set; }
        public string Position { get; set; }
    }
}